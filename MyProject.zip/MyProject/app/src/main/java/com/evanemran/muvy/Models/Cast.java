package com.evanemran.muvy.Models;

public class Cast {
    String actor = "";
    String actor_id = "";
    String character = "";

    public String getActor() {
        return actor;
    }

    public String getActor_id() {
        return actor_id;
    }

    public String getCharacter() {
        return character;
    }
}
