package com.evanemran.muvy.Models;

public class Trailer {
    String id = "";
    String link = "";

    public String getId() {
        return id;
    }

    public String getLink() {
        return link;
    }
}
