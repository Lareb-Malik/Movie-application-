package com.evanemran.muvy;

public interface OnClickedListener {
    void onClicked(String id);
}
