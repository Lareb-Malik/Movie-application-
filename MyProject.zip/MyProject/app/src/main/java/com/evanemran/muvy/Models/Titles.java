package com.evanemran.muvy.Models;

public class Titles {
    String title = "";
    String image = "";
    String id = "";

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public String getId() {
        return id;
    }
}
